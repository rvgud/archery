package com.assignment.test;

import static org.junit.Assert.assertEquals;

import java.lang.reflect.Type;
import java.util.ArrayList;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import com.assignment.dto.Chance;
import com.assignment.service.ScoreService;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class Testcases {
	@Rule
	public ExpectedException exception = ExpectedException.none();

	@Test
	public void testScoreServiceTest1() throws Exception {
		String requestdDataJson = "[{\"chanceID\":1,\"arrows\":[{\"arrowNo\":1,\"value\":4},{\"arrowNo\":2,\"value\":2}]},{\"chanceID\":2,\"arrows\":[{\"arrowNo\":1,\"value\":3},{\"arrowNo\":2,\"value\":4}]},{\"chanceID\":3,\"arrows\":[{\"arrowNo\":1,\"value\":7},{\"arrowNo\":2,\"value\":3}]},{\"chanceID\":4,\"arrows\":[{\"arrowNo\":1,\"value\":10},{\"arrowNo\":2,\"value\":0}]},{\"chanceID\":5,\"arrows\":[{\"arrowNo\":1,\"value\":6},{\"arrowNo\":2,\"value\":0}]},{\"chanceID\":6,\"arrows\":[{\"arrowNo\":1,\"value\":0},{\"arrowNo\":2,\"value\":5}]},{\"chanceID\":7,\"arrows\":[{\"arrowNo\":1,\"value\":9},{\"arrowNo\":2,\"value\":0}]},{\"chanceID\":8,\"arrows\":[{\"arrowNo\":1,\"value\":2},{\"arrowNo\":2,\"value\":1}]},{\"chanceID\":9,\"arrows\":[{\"arrowNo\":1,\"value\":5},{\"arrowNo\":2,\"value\":2}]},{\"chanceID\":10,\"arrows\":[{\"arrowNo\":1,\"value\":10},{\"arrowNo\":2,\"value\":10},{\"arrowNo\":3,\"value\":5}]}]";
		testScore(requestdDataJson, "104");
	}

	@Test
	public void testScoreServiceTest2() throws Exception {
		String requestdDataJson = "[{\"chanceID\":1,\"arrows\":[{\"arrowNo\":1,\"value\":4},{\"arrowNo\":2,\"value\":6}]},{\"chanceID\":2,\"arrows\":[{\"arrowNo\":1,\"value\":10},{\"arrowNo\":2,\"value\":0}]},{\"chanceID\":3,\"arrows\":[{\"arrowNo\":1,\"value\":0},{\"arrowNo\":2,\"value\":10}]},{\"chanceID\":4,\"arrows\":[{\"arrowNo\":1,\"value\":3},{\"arrowNo\":2,\"value\":4}]},{\"chanceID\":5,\"arrows\":[{\"arrowNo\":1,\"value\":3},{\"arrowNo\":2,\"value\":1}]},{\"chanceID\":6,\"arrows\":[{\"arrowNo\":1,\"value\":0},{\"arrowNo\":2,\"value\":5}]},{\"chanceID\":7,\"arrows\":[{\"arrowNo\":1,\"value\":9},{\"arrowNo\":2,\"value\":0}]},{\"chanceID\":8,\"arrows\":[{\"arrowNo\":1,\"value\":2},{\"arrowNo\":2,\"value\":1}]},{\"chanceID\":9,\"arrows\":[{\"arrowNo\":1,\"value\":5},{\"arrowNo\":2,\"value\":2}]},{\"chanceID\":10,\"arrows\":[{\"arrowNo\":1,\"value\":3},{\"arrowNo\":2,\"value\":2},{\"arrowNo\":3,\"value\":0}]}]";
		testScore(requestdDataJson, "97");
	}
	
	private void testScore(String requestdDataJson,String score) throws Exception {
		Gson g = new Gson();
		Type chancetype = new TypeToken<ArrayList<Chance>>() {
		}.getType();
		ArrayList<Chance> chances = g.fromJson(requestdDataJson, chancetype);

		ScoreService scoreService = new ScoreService();

		assertEquals(scoreService.getScore(chances), "97");
	}

}
