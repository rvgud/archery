package com.assignment.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.el.ELException;

import com.assignment.dto.Arrow;
import com.assignment.dto.Chance;

public class ScoreService {

	public String getScore(ArrayList<Chance> chances) throws Exception {
		Collections.sort(chances);
		int sum = 0;
		for (int i = 0; i < chances.size() - 1; i++) {
			int score = calculateScore(chances, i);
			sum = sum + score;
		}
		sum = sum + calculateLastChanceScore(chances.get(chances.size() - 1));
		return String.valueOf(sum);
	}

	private Integer calculateScore(ArrayList<Chance> lstChance, int index) throws Exception {
		Chance chance = lstChance.get(index);
		List<Arrow> lstArrow = chance.getArrows();
		int sum = 0;
		boolean isPerfectScore = false;
		for (Arrow arrow : lstArrow) {
			if (arrow.getValue() == 10) {
				isPerfectScore = true;
			}
			sum = sum + arrow.getValue();
			if(sum>10) {
			     throw new Exception("Sum should be less then 10!");
			}
		}

		if (sum == 10) {
			if (isPerfectScore) {
				Chance nextChance = lstChance.get(index + 1);
				List<Arrow> lstNextArrow = nextChance.getArrows();
				for (int i = 0; i < 2; i++) {
					sum = sum + lstNextArrow.get(i).getValue();
				}
			} else {
				Chance nextChance = lstChance.get(index + 1);
				for (Arrow arrow : nextChance.getArrows()) {
					if (arrow.getArrowNo() == 1) {
						sum = sum + arrow.getValue();
						break;
					}
				}

			}
		}
		return sum;
	}

	private Integer calculateLastChanceScore(Chance chance) {
		int arrowOneValue = 0;
		int arrowTwoValue = 0;
		int arrowThreeValue = 0;

		for (Arrow arrow : chance.getArrows()) {
			switch (arrow.getArrowNo()) {
			case 1:
				arrowOneValue = arrow.getValue();
				break;
			case 2:
				arrowTwoValue = arrow.getValue();
				break;
			case 3:
				arrowThreeValue = arrow.getValue();
				break;

			default:
				break;
			}

		}
		return arrowOneValue + arrowTwoValue + arrowThreeValue;
	}

}
