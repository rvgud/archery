package com.assignment.dto;

import java.util.List;


public class Chance  implements Comparable<Chance> {
	
	private int chanceID;
	List<Arrow> arrows;
	public int getChanceID() {
		return chanceID;
	}
	public void setChanceID(int chanceID) {
		this.chanceID = chanceID;
	}
	public List<Arrow> getArrows() {
		return arrows;
	}
	public void setArrows(List<Arrow> arrows) {
		this.arrows = arrows;
	}
	
	public int compareTo(Chance chance) {
		int id=((Chance)chance).getChanceID();
        return this.chanceID-id;
	}
	
}
