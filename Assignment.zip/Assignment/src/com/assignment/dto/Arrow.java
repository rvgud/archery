package com.assignment.dto;

public class Arrow {
	private int arrowNo;
	private int value;
	public int getArrowNo() {
		return arrowNo;
	}
	public void setArrowNo(int arrowNo) {
		this.arrowNo = arrowNo;
	}
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
}
