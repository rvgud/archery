package com.assignment.api;

import java.lang.reflect.Type;
import java.util.ArrayList;

//Git
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.assignment.dto.Chance;
import com.assignment.service.ScoreService;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

@Path("/Users")
public class Client {

	@POST
	@Path("/Score")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response insertPrice(String datarecieved) throws Exception {
		Response response = null;
		Gson g = new Gson();
		Type chancetype = new TypeToken<ArrayList<Chance>>() {
		}.getType();
		ArrayList<Chance> chances = g.fromJson(datarecieved, chancetype);
		try {
			ScoreService sservice = new ScoreService();
			String returnString = sservice.getScore(chances);
			response = Response.ok(g.toJson(returnString)).build();
		} catch (Exception e) {
			response = Response.ok(g.toJson(e.getMessage())).build();
		}
		return response;
	}

}